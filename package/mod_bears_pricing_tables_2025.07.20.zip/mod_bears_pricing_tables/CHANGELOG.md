# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2025.07.20] - 2025-07-20

### Changed

* Update version to 2025.06.24 [skip ci] ([e6d87bf](https://github.com/N6REJ/mod_bears_pricing_tables/commit/e6d87bf))
* Update module-packager.yml ([5df905a](https://github.com/N6REJ/mod_bears_pricing_tables/commit/5df905a))
* Update module-packager.yml ([c15ba86](https://github.com/N6REJ/mod_bears_pricing_tables/commit/c15ba86))
* Update version to 2025.07.18 [skip ci] ([ebae549](https://github.com/N6REJ/mod_bears_pricing_tables/commit/ebae549))
* Update module-packager.yml ([b4606a7](https://github.com/N6REJ/mod_bears_pricing_tables/commit/b4606a7))

